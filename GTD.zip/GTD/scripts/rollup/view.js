// GTD project rollup — invoked by Dashboard.md via dv.view("GTD/scripts/rollup").
// Hand-rendered (instead of dv.table) so each project link can open in a new tab.

const hasNextTag = (t) =>
    (t.tags || []).some(tag => tag === "#next" || tag === "next");

const pages = dv.pages('#gtd/project AND "GTD/Projects"').array();
pages.sort((a, b) => {
    const areaCmp = String(a.area || "").localeCompare(String(b.area || ""));
    if (areaCmp !== 0) return areaCmp;
    return a.file.name.localeCompare(b.file.name);
});

const table = document.createElement("table");
table.className = "dataview table-view-table";

const thead = document.createElement("thead");
const headerRow = document.createElement("tr");
for (const label of ["Project", "Area", "Status", "Open", "Next"]) {
    const th = document.createElement("th");
    th.textContent = label;
    headerRow.appendChild(th);
}
thead.appendChild(headerRow);
table.appendChild(thead);

const tbody = document.createElement("tbody");
for (const p of pages) {
    const tasks = p.file.tasks || [];
    const open = tasks.filter(t => !t.completed).length;
    const next = tasks.filter(t => !t.completed && hasNextTag(t)).length;

    const row = document.createElement("tr");

    // Project name cell — link opens in a new tab on click.
    const projCell = document.createElement("td");
    const a = document.createElement("a");
    a.className = "internal-link";
    a.textContent = p.file.name;
    a.href = p.file.path;
    a.dataset.href = p.file.path;
    a.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        app.workspace.openLinkText(p.file.path, "", "tab");
    });
    projCell.appendChild(a);
    row.appendChild(projCell);

    for (const value of [p.area || "", p.status || "", String(open), String(next)]) {
        const td = document.createElement("td");
        td.textContent = value;
        row.appendChild(td);
    }

    tbody.appendChild(row);
}
table.appendChild(tbody);

dv.container.appendChild(table);
