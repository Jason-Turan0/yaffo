// GTD Dashboard view — invoked by Dashboard.md via dv.view("GTD/scripts/dashboard").

// ---------- Controls ----------
const controls = dv.container.appendChild(document.createElement("div"));
controls.style.display = "flex";
controls.style.flexWrap = "wrap";
controls.style.gap = "16px";
controls.style.alignItems = "center";
controls.style.padding = "10px 0";
controls.style.borderBottom = "1px solid var(--background-modifier-border)";
controls.style.marginBottom = "12px";

function makeSelect(label, options) {
    const wrap = document.createElement("label");
    wrap.style.display = "flex";
    wrap.style.alignItems = "center";
    wrap.style.gap = "6px";
    wrap.style.fontSize = "0.85em";
    wrap.append(label + ":");
    const sel = document.createElement("select");
    sel.style.padding = "2px 6px";
    for (const [value, text] of options) {
        const o = document.createElement("option");
        o.value = value;
        o.textContent = text;
        sel.appendChild(o);
    }
    wrap.appendChild(sel);
    controls.appendChild(wrap);
    return sel;
}

function makeSearch() {
    const wrap = document.createElement("label");
    wrap.style.display = "flex";
    wrap.style.alignItems = "center";
    wrap.style.gap = "6px";
    wrap.style.fontSize = "0.85em";
    wrap.append("Search:");
    const input = document.createElement("input");
    input.type = "search";
    input.placeholder = "filter text…";
    input.style.padding = "2px 6px";
    wrap.appendChild(input);
    controls.appendChild(wrap);
    return input;
}

function makeCheckbox(label) {
    const wrap = document.createElement("label");
    wrap.style.display = "flex";
    wrap.style.alignItems = "center";
    wrap.style.gap = "4px";
    wrap.style.fontSize = "0.85em";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    wrap.appendChild(cb);
    wrap.append(label);
    controls.appendChild(wrap);
    return cb;
}

const viewSel = makeSelect("View", [
    ["next",    "Next actions"],
    ["open",    "All open"],
    ["waiting", "Waiting on"],
    ["due",     "Due ≤14 days"],
    ["stale",   "Stale (no due, untouched >30d)"],
]);
// Areas are looked up from `GTD/Areas/*.md` files tagged `#gtd/area` rather
// than hard-coded — adding/renaming an area file shows up here on next render.
const areaOptions = [["all", "All"]];
for (const a of dv.pages('#gtd/area AND "GTD/Areas"').sort(p => p.file.name).array()) {
    areaOptions.push([a.file.name, a.file.name]);
}
const areaSel = makeSelect("Area", areaOptions);
const projSel = makeSelect("Project", [["all", "All"]]);
const search  = makeSearch();
const showCompletedCb = makeCheckbox("Show completed");

// ---------- Results panel ----------
const results = dv.container.appendChild(document.createElement("div"));

// ---------- Data ----------
function queryProjects() {
    return dv.pages('#gtd/project AND "GTD/Projects"');
}

function refreshProjectOptions() {
    const area = areaSel.value;
    const opts = queryProjects()
        .where(p => area === "all" || p.area === area)
        .sort(p => p.file.name)
        .array();
    while (projSel.options.length > 1) projSel.remove(1);
    for (const p of opts) {
        const o = document.createElement("option");
        o.value = p.file.name;
        o.textContent = `${p.file.name} (${p.area})`;
        projSel.appendChild(o);
    }
}

// ---------- Tag-based metadata helpers ----------
const hasTag = (t, name) => {
    const tags = t.tags || [];
    return tags.some(x => x === name || x === "#" + name || x === name.replace(/^#/, ""));
};

function getDueDate(task) {
    // Dataview parses the Tasks-plugin 📅 emoji into task.due (Luxon DateTime).
    return task.due ?? null;
}

function getWaitingDate(task) {
    for (const t of (task.tags || [])) {
        const m = String(t).match(/^#?waiting\/(\d{4}-\d{2}-\d{2})$/);
        if (m) return dv.date(m[1]);
    }
    return null;
}

function isWaiting(task) {
    return (task.tags || []).some(t => /^#?waiting(\/.*)?$/.test(String(t)));
}

function isSomeday(task) {
    return hasTag(task, "someday");
}

// ---------- Mutations ----------
// Read a file's lines for in-place line edits.
async function readLines(path) {
    const file = app.vault.getAbstractFileByPath(path);
    if (!file || !("extension" in file)) return null;
    try {
        const content = await app.vault.read(file);
        return { file, lines: content.split("\n") };
    } catch (e) {
        return null;
    }
}

async function toggleTaskCompleted(t, checked) {
    const data = await readLines(t.path);
    if (!data) return;
    const { file, lines } = data;
    const line = lines[t.line];
    if (typeof line !== "string") return;
    const updated = checked
        ? line.replace(/^(\s*-\s*)\[\s\]/, "$1[x]")
        : line.replace(/^(\s*-\s*)\[[xX]\]/, "$1[ ]");
    if (updated === line) return;
    lines[t.line] = updated;
    await app.vault.modify(file, lines.join("\n"));
}

async function replaceTaskText(t, newText) {
    const data = await readLines(t.path);
    if (!data) return;
    const { file, lines } = data;
    const line = lines[t.line];
    if (typeof line !== "string") return;
    // Capture leading whitespace + "- [x] " (or "- [ ] ") prefix; replace text after.
    const m = line.match(/^(\s*-\s*\[[^\]]\]\s*)(.*)$/);
    if (!m) return;
    const updated = m[1] + newText;
    if (updated === line) return;
    lines[t.line] = updated;
    await app.vault.modify(file, lines.join("\n"));
}

// Append a new task to the project file's "## Tasks" section. If the section
// contains the "_No open tasks._" placeholder, that line is replaced; otherwise
// the new task is inserted after the last non-blank line of the section.
async function addTask(projectPath, taskText) {
    const data = await readLines(projectPath);
    if (!data) return;
    const { file, lines } = data;
    const tasksIdx = lines.findIndex(l => /^##\s+Tasks\s*$/.test(l));
    if (tasksIdx === -1) return;
    let sectionEnd = lines.length;
    for (let i = tasksIdx + 1; i < lines.length; i++) {
        if (/^##\s+/.test(lines[i])) { sectionEnd = i; break; }
    }
    let lastIdx = sectionEnd - 1;
    while (lastIdx > tasksIdx && lines[lastIdx].trim() === "") lastIdx--;
    if (lastIdx > tasksIdx && /^_No open tasks\.?_\s*$/.test(lines[lastIdx])) {
        lines[lastIdx] = `- [ ] ${taskText}`;
    } else {
        lines.splice(lastIdx + 1, 0, `- [ ] ${taskText}`);
    }
    await app.vault.modify(file, lines.join("\n"));
}

// ---------- Task text rendering ----------
// Mirror the Tasks plugin's visual treatment: hashtags become Obsidian tag
// chips, Tasks-plugin date/recurrence/priority emojis get wrapped in spans
// with `task-*` classes (matching the Tasks plugin's own DOM, so its CSS
// picks them up if loaded). Inline `opacity`/`marginLeft` is a fallback for
// when only Obsidian's base theme is active. Unrecognized text falls through
// as a plain text node so we never drop content.
const TASK_TOKEN_RE = /(#[\w/\-]+)|([📅⏳🛫✅➕])\s*(\d{4}-\d{2}-\d{2})|(🔁)[ \t]+([^📅⏳🛫✅➕#⏫🔼🔽🔺⏬\n]*?)(?=\s*(?:[📅⏳🛫✅➕#⏫🔼🔽🔺⏬]|$))|([⏫🔼🔽🔺⏬])/gu;

const TASK_DATE_CLASS = {
    "📅": "task-due",
    "⏳": "task-scheduled",
    "🛫": "task-start",
    "✅": "task-done",
    "➕": "task-created",
};

function renderTaskText(parent, text) {
    while (parent.firstChild) parent.removeChild(parent.firstChild);
    TASK_TOKEN_RE.lastIndex = 0;
    let lastIdx = 0;
    let m;
    while ((m = TASK_TOKEN_RE.exec(text)) !== null) {
        if (m.index > lastIdx) {
            parent.appendChild(document.createTextNode(text.slice(lastIdx, m.index)));
        }
        if (m[1]) {
            // #tag — `class="tag"` picks up Obsidian's built-in chip styling.
            const a = document.createElement("a");
            a.className = "tag";
            a.href = m[1];
            a.dataset.href = m[1];
            a.target = "_blank";
            a.rel = "noopener";
            a.textContent = m[1];
            parent.appendChild(a);
        } else if (m[2]) {
            // Date emoji + ISO date.
            const cls = TASK_DATE_CLASS[m[2]] || "task-date";
            const wrap = document.createElement("span");
            wrap.className = cls;
            wrap.style.marginLeft = "6px";
            wrap.style.opacity = "0.7";
            const e = document.createElement("span");
            e.className = `${cls}-emoji`;
            e.textContent = m[2];
            const d = document.createElement("span");
            d.className = `${cls}-date`;
            d.textContent = " " + m[3];
            wrap.append(e, d);
            parent.appendChild(wrap);
        } else if (m[4]) {
            // 🔁 + rule (rule extends to next emoji/tag boundary).
            const wrap = document.createElement("span");
            wrap.className = "task-recurring";
            wrap.style.marginLeft = "6px";
            wrap.style.opacity = "0.7";
            const e = document.createElement("span");
            e.className = "task-recurring-emoji";
            e.textContent = m[4];
            const r = document.createElement("span");
            r.className = "task-recurring-rule";
            r.textContent = " " + m[5].trim();
            wrap.append(e, r);
            parent.appendChild(wrap);
        } else if (m[6]) {
            // Priority emoji.
            const s = document.createElement("span");
            s.className = "task-priority";
            s.style.marginLeft = "6px";
            s.textContent = m[6];
            parent.appendChild(s);
        }
        lastIdx = m.index + m[0].length;
    }
    if (lastIdx < text.length) {
        parent.appendChild(document.createTextNode(text.slice(lastIdx)));
    }
}

// ---------- Render ----------
// "+ Add task" link that expands into a single-line input below a project group.
function appendAddTaskRow(container, projectPath) {
    const wrap = document.createElement("div");
    wrap.style.paddingLeft = "16px";
    wrap.style.marginTop = "4px";
    wrap.style.fontSize = "0.9em";

    const link = document.createElement("a");
    link.href = "#";
    link.textContent = "+ Add task";
    link.style.opacity = "0.6";
    link.style.cursor = "pointer";

    const form = document.createElement("div");
    form.style.display = "none";
    form.style.alignItems = "center";
    form.style.gap = "6px";

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.disabled = true;

    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "New task…";
    input.style.flex = "1";
    input.style.padding = "2px 4px";
    input.style.border = "1px solid var(--background-modifier-border)";
    input.style.background = "var(--background-primary)";
    input.style.color = "var(--text-normal)";

    form.appendChild(cb);
    form.appendChild(input);

    const showForm = () => {
        link.style.display = "none";
        form.style.display = "flex";
        input.focus();
    };
    const hideForm = () => {
        input.value = "";
        form.style.display = "none";
        link.style.display = "";
    };

    link.addEventListener("click", (e) => {
        e.preventDefault();
        showForm();
    });

    input.addEventListener("keydown", async (e) => {
        if (e.key === "Enter") {
            e.preventDefault();
            const text = input.value.trim();
            if (!text) { hideForm(); return; }
            input.disabled = true;
            try {
                await addTask(projectPath, text);
                setTimeout(render, 250);
            } finally {
                input.disabled = false;
            }
        } else if (e.key === "Escape") {
            e.preventDefault();
            hideForm();
        }
    });

    input.addEventListener("blur", () => {
        if (input.value.trim() === "") hideForm();
    });

    wrap.appendChild(link);
    wrap.appendChild(form);
    container.appendChild(wrap);
}

function renderTaskGroup(container, projName, projPath, items) {
    const frag = document.createDocumentFragment();

    const h = document.createElement("h4");
    h.style.margin = "12px 0 4px";
    const a = document.createElement("a");
    a.className = "internal-link";
    a.dataset.href = projPath;
    a.href = projPath;
    a.textContent = projName;
    a.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        // newLeaf=true → open in new tab; "tab" preserves split layout if any.
        app.workspace.openLinkText(projPath, "", "tab");
    });
    h.appendChild(a);
    const count = document.createElement("span");
    count.style.opacity = "0.6";
    count.style.fontWeight = "normal";
    count.style.marginLeft = "6px";
    count.textContent = `(${items.length})`;
    h.appendChild(count);
    frag.appendChild(h);

    if (items.length === 0) {
        appendAddTaskRow(frag, projPath);
        container.appendChild(frag);
        return;
    }

    const ul = document.createElement("ul");
    ul.className = "contains-task-list";
    ul.style.listStyle = "none";
    ul.style.paddingLeft = "16px";
    items.sort((a, b) => Number(!!a.completed) - Number(!!b.completed));
    for (const t of items) {
        const li = document.createElement("li");
        li.className = "task-list-item";

        // Checkbox toggles completion in the source file.
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.checked = !!t.completed;
        cb.style.marginRight = "6px";
        li.appendChild(cb);

        // Text: double-click to edit; Enter/blur saves; Escape cancels.
        const span = document.createElement("span");
        renderTaskText(span, t.text || "");
        span.title = "Double-click to edit";
        span.style.cursor = "text";
        if (t.completed) {
            span.style.textDecoration = "line-through";
            span.style.opacity = "0.6";
        }
        li.appendChild(span);

        cb.addEventListener("change", async () => {
            cb.disabled = true;
            try {
                await toggleTaskCompleted(t, cb.checked);
                t.completed = cb.checked;
                span.style.textDecoration = cb.checked ? "line-through" : "";
                span.style.opacity = cb.checked ? "0.6" : "";
                // Re-render after Dataview re-indexes so the view reflects the new state.
                setTimeout(render, 250);
            } finally {
                cb.disabled = false;
            }
        });

        let editing = false;
        let originalText = t.text || "";

        span.addEventListener("dblclick", () => {
            if (editing) return;
            editing = true;
            // Capture flat text and replace structured children with one text
            // node, so the user edits the raw markdown (tags + emojis) — not
            // styled chips inside a contenteditable.
            originalText = span.textContent;
            span.textContent = originalText;
            span.contentEditable = "true";
            span.style.outline = "1px solid var(--interactive-accent)";
            span.style.padding = "0 2px";
            span.focus();
            const range = document.createRange();
            range.selectNodeContents(span);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        });

        const exitEdit = async (save) => {
            if (!editing) return;
            editing = false;
            span.contentEditable = "false";
            span.style.outline = "";
            span.style.padding = "";
            if (save) {
                const newText = span.textContent.replace(/\n/g, " ").trim();
                if (newText && newText !== originalText) {
                    await replaceTaskText(t, newText);
                    t.text = newText;
                    renderTaskText(span, newText);
                } else {
                    renderTaskText(span, originalText);
                }
            } else {
                renderTaskText(span, originalText);
            }
        };

        span.addEventListener("blur", () => exitEdit(true));
        span.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                e.preventDefault();
                span.blur();
            } else if (e.key === "Escape") {
                e.preventDefault();
                exitEdit(false);
            }
        });

        ul.appendChild(li);
    }
    frag.appendChild(ul);
    appendAddTaskRow(frag, projPath);
    container.appendChild(frag);
}

const acceptable = (t) =>
    !t.completed && !isWaiting(t) && !isSomeday(t);

function firstLeafTask(rootTasks) {
    const root = rootTasks.find(acceptable);
    if (!root) return null;
    let cur = root;
    while (true) {
        const opens = (cur.subtasks || []).filter(acceptable);
        if (opens.length === 0) return cur;
        cur = opens[0];
    }
}

async function render() {
    results.innerHTML = "";

    const view = viewSel.value;
    const area = areaSel.value;
    const proj = projSel.value;
    const q    = search.value.trim().toLowerCase();
    const showCompleted = showCompletedCb.checked;

    let pagesQ = queryProjects();
    if (area !== "all") pagesQ = pagesQ.where(p => p.area === area);
    if (proj !== "all") pagesQ = pagesQ.where(p => p.file.name === proj);
    const pagesArr = pagesQ.array();

    const mtimeByPath = new Map();
    for (const p of pagesArr) mtimeByPath.set(p.file.path, p.file.mtime);

    const today = dv.date("today");
    const in14  = today.plus({ days: 14 });
    const ago30 = today.minus({ days: 30 });

    let tasks;

    if (view === "next") {
        const seen = new Set();
        const result = [];
        const add = (t) => { if (t && !seen.has(t)) { seen.add(t); result.push(t); } };
        for (const page of pagesArr) {
            const allTasks = page.file.tasks;
            for (const t of allTasks) {
                if (!t.completed && hasTag(t, "next")) add(t);
            }
            const roots = allTasks.filter(t => t.parent === undefined);
            add(firstLeafTask([...roots]));
            if (showCompleted) {
                for (const t of allTasks) if (t.completed) add(t);
            }
        }
        tasks = result;
    } else {
        const flat = [];
        for (const page of pagesArr) {
            for (const t of page.file.tasks) flat.push(t);
        }
        tasks = flat.filter(t => {
            if (!showCompleted && t.completed) return false;
            if (view === "waiting") return isWaiting(t);
            if (view === "open")    return !isWaiting(t);
            if (view === "due") {
                const d = getDueDate(t);
                return d && d <= in14;
            }
            if (view === "stale") {
                if (getDueDate(t)) return false;
                const m = mtimeByPath.get(t.path);
                return m && m < ago30;
            }
            return true;
        });
    }

    if (q) tasks = tasks.filter(t => (t.text || "").toLowerCase().includes(q));

    const summary = document.createElement("div");
    summary.style.fontSize = "0.85em";
    summary.style.opacity = "0.75";
    summary.style.marginBottom = "8px";
    summary.textContent = `${tasks.length} task(s)`;
    results.appendChild(summary);

    if (tasks.length === 0 && proj === "all") {
        const empty = document.createElement("div");
        empty.textContent = "No tasks match these filters.";
        empty.style.fontStyle = "italic";
        empty.style.opacity = "0.7";
        results.appendChild(empty);
        return;
    }

    const groups = new Map();
    for (const t of tasks) {
        const path = t.path || (t.link && t.link.path) || "(unknown)";
        if (!groups.has(path)) groups.set(path, []);
        groups.get(path).push(t);
    }

    // When a specific project is selected, always render its group — even if
    // empty — so the user has somewhere to add new tasks.
    if (proj !== "all") {
        for (const p of pagesArr) {
            if (!groups.has(p.file.path)) groups.set(p.file.path, []);
        }
    }

    const sorted = [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0]));
    for (const [path, items] of sorted) {
        const projName = path.split("/").pop().replace(/\.md$/, "");
        renderTaskGroup(results, projName, path, items);
    }
}

let searchTimer = null;
function debouncedRender() {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(render, 200);
}

areaSel.addEventListener("change", () => { refreshProjectOptions(); render(); });
viewSel.addEventListener("change", render);
projSel.addEventListener("change", render);
search.addEventListener("input", debouncedRender);
showCompletedCb.addEventListener("change", render);

refreshProjectOptions();
render();
