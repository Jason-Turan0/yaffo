---
tags:
  - gtd/someday
---
_Items parked for later. Move to a project when ready._

## Contract Work?

- [ ] Contract Work? #someday
    - [ ] Research #someday
