---
area: Home
status: active
gtd-id: 1f0177f3-eb48-48c3-9507-9bf5e6c2dba9
created: '2018-11-19'
tags:
  - gtd/project
---
## Tasks

- [ ] Chevy Cavalier
    - [ ] Repairs
        - [ ] Tires #next
        - [ ] Auto Registration #next 

## Reference

See [[Reference]] for historical and reference content.
