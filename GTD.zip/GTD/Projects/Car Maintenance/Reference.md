---
tags: [gtd/reference]
project: Car Maintenance
---
## Chevy Cavalier / Log

### 12/15/2018

Replaced windshield wipers

### 9/10/2019

110k

Oil change high mileage

Replaced battery

Brake fluid 

Air filter

### 7/25/2020

Safety and emissions inspection

Renewed vehicle registration online

### 7/11/2022

Oil Change

Emisssions Inspection passed

Safety inspection failed - Need new tire

### 7/16/2022

Change two front tires

Tire Alignment

### 9/13/2022

Safety inspection

Emissions inspection

### 10/11/2025

Oil change 125k

Brake fluid change

Steger service

9200 Manchester Rd, Brentwood, MO 631449200 Manchester Rd, Brentwood, MO 63144

