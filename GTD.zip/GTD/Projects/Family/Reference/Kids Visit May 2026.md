---
tags:
  - gtd/reference
project: Family
---

# Kids Visit — May 23–29, 2026

Chase (9) + Nathan (6) in Chicago for the week. Pickup in St. Louis May 23, drop-off May 29.

## Logistics

- **Travel out (May 23, Sat):** Amtrak Chicago → St. Louis, then drive kids back to Chicago.
- **Travel back (May 29, Fri):** Drive kids to St. Louis, Amtrak back to Chicago.
- **Lodging:** Mom's HomeExchange in Chicago for the week. Apartment is 1BR — wouldn't fit three plus grandma. Stay at the HomeExchange with her and the kids the whole week.
- **Car:** Driving own car. In decent enough shape for the trip.

## Day-by-day sketch

- **Sat May 23** — Travel day. Amtrak down, pick up kids, drive back. Probably arrive Chicago evening — low-key dinner at the HomeExchange.
- **Sun May 24 — Lincoln Square day (recovery + neighborhood walk):**
    - **Late morning:** sleep in, casual breakfast at HomeExchange. Drive to Lincoln Square (~10 min).
    - **Welles Park** (2333 W Sunnyside) — playground, tin man statue, kids burn energy on grass. Anchor of the day.
    - **Walk Lincoln Ave** between Lawrence and Wilson:
        - **Timeless Toys** (4749 N Lincoln) — indie toy store, easy 30 min.
        - **The Book Cellar** (4736 N Lincoln) — indie bookstore + wine bar; kids browse, mom sits.
        - **Merz Apothecary** (4716 N Lincoln) — old German apothecary, weird and fun.
        - **Giddings Plaza** — fountain, benches, sometimes performers. Gelato break at **Paciugo**.
        - **Old Town School of Folk Music** (4544 N Lincoln) — check Sunday family programming in advance.
    - **Lunch:** Spacca Napoli (Neapolitan pizza, kid hit).
    - **Sweet stop with mom:** Lutz Café & Pastry Shop on the way out.
    - **Back to base** mid-afternoon, decompress before tomorrow's Lincoln Park day.
    - **Dinner:** at the HomeExchange — easy family meal.
- **Mon May 25 — Memorial Day — Lincoln Park day:**
    - **10 AM:** Lincoln Park Zoo (free, opens 10). Hit Regenstein Macaque Forest, the lion house, Pritzker Children's Zoo, Farm-in-the-Zoo. ~2 hours.
    - **Lunch:** R.J. Grunts (2056 N Lincoln Park West) — classic family spot across from the zoo, big menu, salad bar, milkshakes.
    - **Afternoon:** Peggy Notebaert Nature Museum next door (butterfly haven is the kid magnet) OR paddleboats on South Pond if weather's good OR walk south to North Ave Beach (~15 min) for beach time. Pick based on energy + weather.
    - **Back to base** for kids to rest.
    - **Dinner:** Smoque BBQ — walkable from HomeExchange, Memorial Day + Chicago BBQ is thematic. Get there by 5:30 to beat the holiday line.
    - **Evening:** low-key. Don't stack a nighttime event on top.
- **Tue May 26** — **Cubs + Big Mini Putt Club combo.** Day game at Wrigley (1:20 if schedule cooperates, non-rival opponent), then walk/short drive to Big Mini Putt for the afternoon/evening. Dinner somewhere in Lakeview on the way back.
- **Wed May 27** — **Brookfield combo with mom.** Brookfield Zoo in the morning (mom likes zoos, kids burn energy walking), Galloping Ghost arcade in the afternoon — they're ~5 min apart. One efficient trip out west.
- **Thu May 28 — Navy Pier day:**
    - **Morning:** sleep in, casual breakfast at HomeExchange.
    - **Mid-morning:** rideshare to Navy Pier (don't drive — parking's brutal and expensive).
    - **Centennial Wheel first thing** — right at 10 AM opening, before lines build.
    - **Chicago Children's Museum** (on the Pier) — hands-on, both kids dig it. ~90 min.
    - **Crystal Gardens** (free) + **Funhouse Maze** as filler.
    - **Lunch:** Giordano's deep dish on the Pier — Chicago classic + trip finale meal.
    - **Afternoon: Architecture boat tour** — Wendella or Chicago Line, departs from the Pier, ~75 min. **Book tickets in advance.**
    - **Late afternoon:** rideshare back to base, kids decompress, start packing.
    - **Dinner at HomeExchange with mom** — last family meal before the drive.
- **Fri May 29** — Travel back. Pack up morning, drive to St. Louis, Amtrak home.

## Activities to confirm

- **Cubs game** — pick a Tue/Wed/Thu day game (1:20 PM). Avoid Cardinals/Brewers/Yankees/Dodgers series. SeatGeek/StubHub usually beats face value. (Tracked as task in `[[Family]]`.)
- **Big Mini Putt Club** — paired with Cubs day. Confirm hours and whether reservation needed.
- **Galloping Ghost** (Brookfield) — no reservation needed; just show up. Confirm hours.
- **Brookfield Zoo** — buy tickets day-of or in advance online; check parking situation.
- **Architecture boat tour** — Wendella or Chicago Line, Thursday afternoon departure from Navy Pier. **Book ahead** — weekday afternoons in summer fill up.

## Food — walking distance from HomeExchange (Irving Park Blue Line area)

- **Smoque BBQ** (3800 N Pulaski) — the obvious one. World-class Chicago BBQ, counter service, casual, kid-proof. Brisket, ribs, mac & cheese. ~5 min walk south of the Blue Line stop.
- **Honey Butter Fried Chicken** (3361 N Elston) — fried chicken with the namesake honey butter on cornbread. Kids love it. Longer walk (~20 min) or a short drive.
- **La Villa Pizzeria** or local thin-crust spot for a casual pizza night in.
- For a sit-down dinner with mom, worth driving 10–15 min — Logan Square (Lula Café, Longman & Eagle) or Avondale (Parson's Chicken & Fish) open up a lot more.

Verify hours before going — some of these have weird off-days.

## Open questions

- What time does the Amtrak run May 23 / May 29? Book once decided.
- Does mom want any specific outings on the calendar with the kids?
- Any food asks from the boys to plan around?
