---
area: Family
status: active
gtd-id: b2bd32ef-7413-4460-8f0a-55a2ad9ebb33
created: 2017-08-22
tags:
  - gtd/project
---
## Tasks
    
- [ ] Vacation
	- [ ] Reserve train #next 
	- [ ] Find activities #next 
	- [ ] Buy Cubs tickets (weekday day game, non-rival opponent — check SeatGeek/StubHub) #next 
	- [ ] Book architecture boat tour (Thu May 28 PM, Wendella or Chicago Line) 📅 2026-05-16
	- [ ] Buy Brookfield Zoo tickets online (Wed May 27) 📅 2026-05-20
	- [ ] Confirm Big Mini Putt Club hours / reservation (Tue May 26) 📅 2026-05-20
	- [ ] Coordinate pickup/dropoff times with Daina 📅 2026-05-14
	- [ ] Car road-trip prep — oil, tires, washer fluid 📅 2026-05-20
