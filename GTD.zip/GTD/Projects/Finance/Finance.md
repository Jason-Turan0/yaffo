---
area: Home
status: active
gtd-id: 4a6eeb6e-8f14-47e0-bab1-9d2f3597d470
created: '2019-11-16'
tags:
  - gtd/project
---
## Tasks

- [ ] Rollover cgi to vanguard - Need to call TRowPrice #next
- [ ] Remove name from home loan for old house #next 
