---
area: Professional Development
status: active
gtd-id: 8339f608-c389-438f-865d-8a77bea81da3
created: '2025-10-05'
tags:
  - gtd/project
---
## Tasks

- [ ] Application features #next
    - [ ] Organize photos screen #next
- [ ] Package application
    How to package and publish a flask app? Can it have background workers?
    - [ ] Research disto options #next
    - [ ] Demo website?
- [ ] UI Test Automation
    - [ ] Research different vendors and tools #next
