---
area: Home
status: active
gtd-id: 7e43b35f-a26b-4d2b-a4f0-80f6e108f491
created: '2023-04-08'
tags:
  - gtd/project
---
## Tasks

- [x] Drivers license #next
- [ ] Phone number #next
