---
area: Home
status: active
gtd-id: 3fcaec73-3815-46ee-96c1-14aa1695ff90
created: '2025-05-15'
tags:
  - gtd/project
---
## Tasks

- [x] Apartment task 1
	- [x] Apartment subtask 1
- [x] Something #next 
- [x] Something
- [ ] Fix bike