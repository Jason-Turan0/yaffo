---
area: Home
status: active
gtd-id: 5c5e1de2-1958-4f8b-9208-7edf5024de22
created: '2020-01-01'
tags:
  - gtd/project
---
## Tasks

- [ ] Vision appointment (new glasses) #next
- [ ] Sleep Apnea #next
- [ ] Primary Care Visit #next
- [ ] ER Bill #next 
- [ ] Workout 🔁 every week on Sunday 📅 2026-05-10
- [ ] Workout 🔁 every Wednesday 📅 2026-05-13
