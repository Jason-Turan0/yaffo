---
tags:
  - gtd/meta
---
# GTD Conventions

Instructions for agents working in `Jason Turan Journal/GTD/`. Follow these conventions exactly when capturing, processing, or organizing tasks.

## Folder layout

```
GTD/
├── AGENTS.md            ← this file
├── Dashboard.md         ← thin shell; calls dv.view() into scripts/dashboard/
├── Inbox.md             ← raw captures
├── Someday-Maybe.md     ← parked items
├── Areas/
│   ├── Home.md
│   ├── Work.md
│   └── Professional Development.md
├── Projects/
│   └── <Project Name>/
│       ├── <Project Name>.md   ← tasks live here
│       └── Reference.md        ← non-task material, logs, links
└── scripts/
    ├── dashboard/
    │   └── view.js      ← Next-actions / All-open / Waiting / Due / Stale widget
    └── rollup/
        └── view.js      ← Project rollup table (one row per project)
```

One project = one folder = one same-named `.md`. Project folder names use Title Case with spaces (e.g., `Car Maintenance`, not `car-maintenance`).

## No restated H1

Don't start a note with an H1 that restates the filename or just adds a generic prefix to it (e.g. `# Health` in `Health.md`, `# GTD Dashboard` in `Dashboard.md`). Obsidian's inline title already shows the filename at the top of every note pane — a redundant H1 just consumes vertical space. Start the body with the first meaningful section heading (`## Tasks`, `## Captures`, etc.) or with content directly.

The exception is when an H1 carries information the filename can't — e.g., `Reference.md` inside a project folder uses `# <Project> — Reference` to disambiguate when the file is opened outside its folder context. If the H1 truly adds context, keep it; otherwise, drop it.

## Task syntax

Use the Tasks plugin's emoji syntax for concepts the plugin natively models (dates, priority, recurrence, completion). Use inline `#tags` for GTD concepts the plugin doesn't model (`#waiting`, `#someday`, `#next`).

| Concept | Syntax | Example |
|---|---|---|
| Due date | `📅 YYYY-MM-DD` | `- [ ] File taxes 📅 2026-04-15` |
| Scheduled | `⏳ YYYY-MM-DD` | `- [ ] Draft slides ⏳ 2026-05-12` |
| Start (defer) | `🛫 YYYY-MM-DD` | `- [ ] Open enrollment 🛫 2026-10-15` |
| Recurrence | `🔁 <rule>` | `- [ ] Pay rent 🔁 every month on the 1st 📅 2026-06-01` |
| High priority | `⏫` | `- [ ] Pay mortgage 📅 2026-05-15 ⏫` |
| Low priority | `🔽` | `- [ ] Reorganize bookshelf 🔽` |
| Completion stamp | `✅ YYYY-MM-DD` | auto-stamped by the plugin on check-off; don't write by hand |
| Waiting on someone/something | `#waiting` | `- [ ] Home loan #waiting` |
| Waiting + follow-up date | `#waiting/YYYY-MM-DD` | `- [ ] Lender callback #waiting/2025-11-15` |
| Parked / not actionable now | `#someday` | (lives in `Someday-Maybe.md`) |

Priority defaults to medium (unmarked). Use `⏫` / `🔽` sparingly — most tasks should have neither.

### Next actions

Do **not** manually tag `#next` by default. The dashboard derives the next action per project as the first acceptable leaf task (skipping `#waiting` and `#someday`). Only add `#next` to override that order — e.g., when a later sibling task is genuinely the right next step.

### Subtasks

Unlimited nesting depth. Mirror the natural breakdown of the work; don't artificially flatten or artificially split. Indent with 4 spaces.

```
- [ ] Chevy Cavalier
    - [ ] Repairs
        - [ ] Tires 📅 2026-06-01
        - [ ] Brake pads
```

### Completed tasks

Leave `- [x]` items checked in place. Do not move them to a "Done" section, don't archive, don't delete. The dashboard hides completed tasks by default and exposes a toggle to show them.

### Recurring tasks

For tasks that repeat (rent, registration, periodic appointments), use the Tasks plugin's native recurrence so the next instance is generated automatically on check-off.

```
- [ ] Pay rent 🔁 every month on the 1st 📅 2026-06-01
- [ ] Water plants 🔁 every 3 days when done 📅 2026-05-12
```

Rule grammar: `every day`, `every N weeks`, `every month on the Nth`, `every year`, `every weekday`, days of the week, ordinals, `last`. Append `when done` to anchor the next instance to the completion date instead of the previous due date.

On check-off the plugin marks the line `- [x] … ✅ YYYY-MM-DD` and inserts a fresh `- [ ]` above with the dates advanced. Leave the `- [x]` line in place per the [Completed tasks](#completed-tasks) rule — the audit trail accumulates by design.

## Project frontmatter

Every project `.md` requires this frontmatter:

```yaml
---
area: Home              # one of: Home | Work | Professional Development
status: active          # one of: active | on-hold | done
gtd-id: <UUID v4>       # generate fresh per project, never reuse
created: YYYY-MM-DD     # creation date (use today when creating)
tags:
  - gtd/project
---
```

- `area` is **required** and **single-valued**. Pick the dominant area; don't use arrays.
- `status: done` stays in place — do not move completed projects to an archive folder.
- `gtd-id` is a stable identifier; once set, never change it.

## Reference subnote

Auto-create a `Reference.md` alongside every new project for non-task material (logs, links, addresses, history).

```yaml
---
tags:
  - gtd/reference
project: <Project Name>
---

# <Project Name> — Reference
```

The project's main `.md` should link to it: `See [[Reference]] for historical and reference content.`

## Workflows

### Creating a new project

1. Create folder `GTD/Projects/<Name>/`.
2. Create `<Name>.md` with full frontmatter (status=active, today's date, fresh UUID v4).
3. Create `Reference.md` with the reference frontmatter and stub heading.
4. Add a `## Tasks` section to the project file; add a "See [[Reference]]" pointer.

### Inbox processing

When asked to process the Inbox:

1. Read every capture in `Inbox.md`.
2. Build a **single batch plan**: for each capture, propose a destination — existing project (by name), new project (with proposed name + area), `Someday-Maybe.md`, or discard.
3. Present the plan and **wait for approval**.
4. On approval, execute the moves: append into target project task lists, create new projects per the workflow above, append to Someday-Maybe, etc. Empty out the processed captures from `Inbox.md`.

### Someday → active promotion

1. Create the new project per the new-project workflow, using the Someday item's title as the project name (rephrase if rough — confirm with user only if ambiguous).
2. Remove the line(s) from `Someday-Maybe.md`. No struck-through audit trail.

### Project completion

Set `status: done` in frontmatter. Leave the folder, files, and tasks in place. The dashboard filters by status.

### Project pause

Set `status: on-hold`. Same as above — files stay put.

## Tags reference

| Tag | Where | Meaning |
|---|---|---|
| `gtd/project` | project frontmatter | marks a project file |
| `gtd/area` | area frontmatter | marks an area file |
| `gtd/inbox` | Inbox.md frontmatter | |
| `gtd/someday` | Someday-Maybe.md frontmatter | |
| `gtd/dashboard` | Dashboard.md frontmatter | |
| `gtd/reference` | Reference subnote frontmatter | |
| `#next` | inline on task | manual override of dashboard's first-leaf next-action |
| `#waiting`, `#waiting/<date>` | inline on task | blocked, optionally with follow-up date |
| `#someday` | inline on task | parked under Someday-Maybe |

Date and priority metadata uses Tasks-plugin emojis (`📅`, `⏳`, `🛫`, `⏫`, `🔽`, `🔁`, `✅`) — see [Task syntax](#task-syntax).

## Dashboard internals

`Dashboard.md` is a thin shell that calls `dv.view("GTD/scripts/dashboard")` — the actual logic lives in `GTD/scripts/dashboard/view.js`. **Edit `view.js`, not the .md.** The shell is kept tiny on purpose: a large dataviewjs code block in the note source caused Obsidian to defer rendering until a scroll/layout event, producing a ~30s wait on note open. Externalizing fixed it.

The view reads task metadata from a mix of Tasks-plugin emojis (parsed by Dataview) and custom GTD tags:

- Due dates from `📅 YYYY-MM-DD` via Dataview's `task.due` (wrapped by `getDueDate`).
- Waiting follow-up dates parsed from `#waiting/YYYY-MM-DD` via `getWaitingDate(task)`.
- `isWaiting(task)` matches `#waiting` and `#waiting/<date>`.
- "Stale" view = open task with no due date in a project file whose `mtime` is >30 days old.
- "Show completed" checkbox toggles inclusion of `- [x]` tasks (rendered struck-through at the bottom of each project group).

### Interactivity

- **Click the checkbox** on a task to mark it complete/incomplete. The script edits the source line in the project file via `app.vault.modify` and re-renders after a short delay so Dataview's index can refresh.
- **Double-click a task's text** to edit it inline. Enter or click-away saves; Escape cancels. The save replaces everything after the `- [ ] ` / `- [x] ` prefix on that line, so inline tags (`#next`, `#waiting`, etc.) and Tasks-plugin emojis (`📅`, `🔁`, etc.) are part of what you're editing — keep them or remove them as you intend.
- **Click a project name** to open that project file in a new tab.
- **"+ Add task" link** under each project group: click to expand into an input, type the task, hit Enter to save. The new line `- [ ] <text>` is appended to the project's `## Tasks` section. If the section currently holds the `_No open tasks._` placeholder, that placeholder is replaced. Pick a single project from the **Project** dropdown to surface its group (and its add-task link) even when no tasks match the current filter.

Mutations are written directly to the Markdown file (line-based regex replacement in `toggleTaskCompleted` / `replaceTaskText` / `addTask`). They preserve indentation, the checkbox prefix, and any continuation lines below the task.

If priority filtering or sorting is added later, detect `⏫` / `🔽` on the task line text.
