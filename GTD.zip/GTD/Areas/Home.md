---
area: Home
tags: [gtd/area]
---
## Projects

```dataview
TABLE WITHOUT ID file.link AS Project, status
FROM "GTD/Projects"
WHERE area = "Home" AND contains(file.tags, "#gtd/project")
SORT file.name ASC
```