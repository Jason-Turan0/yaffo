---
area: Professional Development
tags: [gtd/area]
---
## Projects

```dataview
TABLE WITHOUT ID file.link AS Project, status
FROM "GTD/Projects"
WHERE area = "Professional Development" AND contains(file.tags, "#gtd/project")
SORT file.name ASC
```