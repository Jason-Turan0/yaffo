---
tags:
  - gtd/dashboard
---
```dataviewjs
await dv.view("GTD/scripts/dashboard");
```

---

## Project rollup

```dataviewjs
await dv.view("GTD/scripts/rollup");
```
