---
tags:
  - gtd/inbox
---
_Capture anything here, then process into a project or Someday-Maybe._

## Captures

- [ ] 
